package com.example.harvest;

public class LoginUtils {

    /**
     * Checks to see if password is not 6 characters or longer
     *
     * @param password
     * @return greaterThan5
     */
    public boolean isValidPassword(String password){
        boolean greaterThan5 = password.length() > 5;

        return greaterThan5;
    }

    /**
     * Checks to see if FullName was filled
     *
     * @param fullName
     * @return fullNameExists
     */
    public boolean isValidFullname(String fullName){
        boolean fullNameExists = !fullName.isEmpty();

        return fullNameExists;
    }
}
