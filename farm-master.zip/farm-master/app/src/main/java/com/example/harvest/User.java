package com.example.harvest;

public class User {

    public String fullname, username, email;

    public User(){

    }

    public User(String fullName, String username, String email){
        this.fullname=fullName;
        this.username = username;
        this.email= email;

    }
}
