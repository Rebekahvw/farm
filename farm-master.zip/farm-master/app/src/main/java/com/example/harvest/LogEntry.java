package com.example.harvest;

public class LogEntry {

}
