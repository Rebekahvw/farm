package com.example.harvest;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class CreateAccountTest {

    @Test
    public void aValidPasswordPasses() throws Exception{

        LoginUtils utils = new LoginUtils();

        assertTrue(utils.isValidPassword("123456"));
    }

    @Test
    public void aValidFullNamePasses() throws Exception{

        LoginUtils utils = new LoginUtils();

        assertTrue(utils.isValidFullname("name"));
    }
}