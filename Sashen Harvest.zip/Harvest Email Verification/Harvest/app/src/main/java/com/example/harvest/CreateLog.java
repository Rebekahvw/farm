package com.example.harvest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class CreateLog extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private EditText logName;

    private Button addLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_log);
        mDatabase = FirebaseDatabase.getInstance().getReference("logs");

        logName = (EditText) findViewById(R.id.logName);

        addLog = (Button) findViewById(R.id.addLog);
        addLog.setOnClickListener(view -> {
            createLog();
        });
    }

    void createLog(){
        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser() ;
        String uid = currentFirebaseUser.getUid();
        Log log = new Log(uid, logName.getText().toString().trim());

        mDatabase.setValue(log);
    }

}